# student_information
This is a simple software using C programming language. we can store,edit and see information a particular student 
